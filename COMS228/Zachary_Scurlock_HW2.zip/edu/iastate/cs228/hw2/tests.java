package edu.iastate.cs228.hw2;

public class tests {
//	private static void main (String[] args) {
//		Point[] arr = new Point[3];
//		arr[0] = new Point(-50, -50);
//		arr[1] = new Point(20, 1);
//		arr [2] = new Point(10, -2);
//		AbstractSorter queef = new InsertionSorter(arr);
//		for (int i = 0; i < queef.points.length; ++i) {
//			System.out.println(queef.points[i]);
//		}
//		queef.setComparator(0);
//		System.out.println("Sorted by x");
//		for (int i = 0; i < queef.points.length; ++i) {
//			System.out.println(queef.points[i]);
//		}
//		queef.setComparator(1);
//		System.out.println("Sorted by y");
//		for (int i = 0; i < queef.points.length; ++i) {
//			System.out.println(queef.points[i]);
//		}
//	}
}
